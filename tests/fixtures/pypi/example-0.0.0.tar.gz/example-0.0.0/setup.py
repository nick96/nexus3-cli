# -*- coding: utf-8 -*-
from setuptools import setup

setup(
    name='example',
    version='0.0.0',
)
